import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Load data
file_path = "campaign_data.csv"
df = pd.read_csv(file_path)
print(df.columns.tolist())
df.columns = df.columns.str.strip()

# Normalize column names
df.columns = df.columns.str.strip().str.lower().str.replace(' ', '_')

# Clean data: Handle missing values
df.dropna(subset=['platform', 'Ad_Spend', 'clicks', 'conversions', 'start_date'], inplace=True)

# Convert data types
df['Ad_Spend'] = pd.to_numeric(df['Ad_spend'], errors='coerce')
df['clicks'] = pd.to_numeric(df['clicks'], errors='coerce')
df['conversions'] = pd.to_numeric(df['conversions'], errors='coerce')
df['start_date'] = pd.to_datetime(df['start_date'], errors='coerce')

# Drop rows with invalid dates or zero clicks
df = df.dropna(subset=['start_date'])
df = df[df['clicks'] > 0]

# ---- 1. Total Revenue per Click ----
# Assuming fixed revenue per conversion = $50 (you can change this value)
revenue_per_conversion = 50
df['total_revenue'] = df['conversions'] * revenue_per_conversion
df['revenue_per_click'] = df['total_revenue'] / df['clicks']

# ---- 2. Month with Highest Ad Spend ----
df['month'] = df['start_date'].dt.to_period('M')
monthly_spend = df.groupby('month')['Ad_spend'].sum().sort_values(ascending=False)
top_month = monthly_spend.idxmax()

# ---- 3. Top 5 Platforms by Total Conversions ----
platform_conversions = df.groupby('platform')['conversions'].sum().sort_values(ascending=False).head(5)

# ---- 4. Visualization ----
sns.set(style="whitegrid")

# Bar chart - Top 5 platforms by conversions
plt.figure(figsize=(8, 5))
sns.barplot(x=platform_conversions.index, y=platform_conversions.values, palette="viridis")
plt.title("Top 5 Platforms by Conversions")
plt.xlabel("Platform")
plt.ylabel("Total Conversions")
plt.tight_layout()
plt.show()

# ---- 5. Insights ----
print("Top Month by Ad_Spend:", top_month)
print("\nTop 5 Platforms by Conversions:\n", platform_conversions)
print("\nSample Revenue per Click:\n", df[['campaignid', 'revenue_per_click']].head())