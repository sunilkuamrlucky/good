import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

# Load Excel file
file_path = "Simple_Social_Media_Analysis_30_Rows.xlsx"
campaign_df = pd.read_excel(file_path, sheet_name="Campaign_Details")
performance_df = pd.read_excel(file_path, sheet_name="Social_Media_Performance")
sales_df = pd.read_excel(file_path, sheet_name="Ecommerce_Sales")

# Clean text: remove special characters
campaign_df['Objective'] = campaign_df['Objective'].str.replace(r'[^a-zA-Z0-9 ]', '', regex=True)
campaign_df['Campaign_Name'] = campaign_df['Campaign_Name'].str.replace(r'[^a-zA-Z0-9 ]', '', regex=True)

# Merge data
merged_df = campaign_df.merge(performance_df, on='Campaign_ID', suffixes=('', '_Perf'))
merged_df = merged_df.merge(sales_df[['Campaign_ID', 'Revenue_Generated']], on='Campaign_ID')

# Compute revenue per budget
merged_df['Revenue_per_Budget'] = merged_df['Revenue_Generated'] / merged_df['Budget']

# Average likes per budget
merged_df['Avg_Likes_per_Budget'] = merged_df['Likes'] / merged_df['Budget']

# Most frequent platform by Campaign ID
most_common_platform = merged_df['Platform'].value_counts().idxmax()

# Bar chart: Top 5 objectives
top_objectives = merged_df['Objective'].value_counts().head(5)
plt.figure(figsize=(8, 5))
sns.barplot(x=top_objectives.index, y=top_objectives.values, palette="Blues_d")
plt.title("Top 2 Campaign Objectives")
plt.xlabel("Objective")
plt.ylabel("Frequency")
plt.xticks(rotation=45)
plt.tight_layout()
plt.show()

# Pie chart: Platform distribution
platform_counts = merged_df['Platform'].value_counts()
plt.figure(figsize=(6, 6))
plt.pie(platform_counts, labels=platform_counts.index, autopct='%1.1f%%', startangle=140, colors=sns.color_palette('pastel'))
plt.title("Platform Distribution")
plt.tight_layout()
plt.show()

# Optional: Print key metrics
print("Campaign with most frequent platform usage:", most_common_platform)
print("\nSample of revenue per budget and avg likes per budget:")
print(merged_df[['Campaign_ID', 'Revenue_per_Budget', 'Avg_Likes_per_Budget']].head())