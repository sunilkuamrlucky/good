import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Load the CSV
df = pd.read_csv('Simple_Social_Media_Analysis_30_Rows.csv')

# Preview data
print(df.head())

# Check structure
print(df.info())

# Summary statistics
print(df.describe(include='all'))

# Check missing values
print(df.isnull().sum())

# Option 1: Drop rows with any missing values
df_cleaned = df.dropna()

# Option 2: Fill missing numeric values with median
df_filled = df.fillna(df.median(numeric_only=True))

platform_counts = df_cleaned['platform'].value_counts()


df_filled['Platform'].fillna('Unknown', inplace=True)

# Remove spaces and lowercase column names
df_cleaned.columns = df_cleaned.columns.str.strip().str.lower().str.replace(' ', '_')

# Top 5 Objectives by Count
top_objectives = df_cleaned['objective'].value_counts().head(5)
print("Top 5 Objectives:")
print(top_objectives)
print(df_cleaned.dtypes)

df_cleaned['ad_spend'] = pd.to_numeric(df_cleaned['ad_spend'], errors='coerce')
df_cleaned['clicks'] = pd.to_numeric(df_cleaned['clicks'], errors='coerce')
df_cleaned['impressions'] = pd.to_numeric(df_cleaned['impressions'], errors='coerce')

# Optional: Visualize
plt.figure(figsize=(8,5))
sns.barplot(x=top_objectives.index, y=top_objectives.values)
plt.title('Top 5 Campaign Objectives')
plt.ylabel('Count')
plt.xlabel('Objective')
plt.xticks(rotation=45)
plt.tight_layout()
plt.show()


print(df.head())

platform_counts = df_cleaned['platform'].value_counts()
plt.pie(platform_counts, labels=platform_counts.index, autopct='%1.1f%%', startangle=90)
plt.title('Platform Distribution')
plt.tight_layout()
plt.show()


plt.figure(figsize=(8,5))
sns.barplot(data=df_cleaned, x='platform', y='ad_spend')
plt.title('Ad Spend per Platform')
plt.xticks(rotation=45)
plt.tight_layout()
plt.show()


df_cleaned['start_date'] = pd.to_datetime(df_cleaned['start_date'])
df_cleaned_sorted = df_cleaned.sort_values('start_date')

plt.figure(figsize=(10,5))
sns.lineplot(data=df_cleaned_sorted, x='start_date', y='impressions', hue='platform')
plt.title('Impressions Over Time')
plt.xticks(rotation=45)
plt.tight_layout()
plt.show()


df_cleaned['ctr'] = df_cleaned['clicks'] / df_cleaned['impressions']
print(df_cleaned[['platform', 'clicks', 'impressions', 'ctr']].sort_values('ctr', ascending=False))

if 'revenue' in df_cleaned.columns:
    df_cleaned['roi'] = df_cleaned['revenue'] / df_cleaned['ad_spend']
    print(df_cleaned[['platform', 'roi']].sort_values('roi', ascending=False))
