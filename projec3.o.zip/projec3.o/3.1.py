import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt

# Load CSV file
file_path = "Simple_Social_Media_Analysis_30_Rows.csv"  # Replace with your actual CSV filename
df = pd.read_csv(file_path)

# Clean text: remove special characters
df['Objective'] = df['Objective'].str.replace(r'[^a-zA-Z0-9 ]', '', regex=True)
df['Campaign_Name'] = df['Campaign_Name'].str.replace(r'[^a-zA-Z0-9 ]', '', regex=True)

# Ensure numeric columns
df['Revenue_Generated'] = pd.to_numeric(df['Revenue_Generated'], errors='coerce')
df['Budget'] = pd.to_numeric(df['Budget'], errors='coerce')

# Drop rows with missing key values
df.dropna(subset=['Revenue_Generated', 'Budget', 'Objective', 'Platform', 'Target_Audience'], inplace=True)

# Total revenue per budget
df['Revenue_per_Budget'] = df['Revenue_Generated'] / df['Budget']

# Bar Chart: Top 5 Objectives
top_objectives = df['Objective'].value_counts().head(5)
sns.set(style="whitegrid")
plt.figure(figsize=(8, 5))
sns.barplot(x=top_objectives.index, y=top_objectives.values, palette='Blues_d')
plt.title("Top 5 Campaign Objectives")
plt.xlabel("Objective")
plt.ylabel("Count")
plt.xticks(rotation=45)
plt.tight_layout()
plt.show()

# Pie Chart: Platform Distribution
platform_counts = df['Platform'].value_counts()
plt.figure(figsize=(6, 6))
plt.pie(platform_counts, labels=platform_counts.index, autopct='%1.1f%%', startangle=140, colors=sns.color_palette("pastel"))
plt.title("Platform Distribution")
plt.tight_layout()
plt.show()

# Bar Chart: Target Audience Distribution
audience_counts = df['Target_Audience'].value_counts()
plt.figure(figsize=(8, 5))
sns.barplot(x=audience_counts.index, y=audience_counts.values, palette='Set2')
plt.title("Target Audience Distribution")
plt.xlabel("Target Audience")
plt.ylabel("Count")
plt.tight_layout()
plt.show()

# Optional: Print summary
print("Top 5 Objectives:\n", top_objectives)
print("\nRevenue per Budget (sample):\n", df[['Campaign_ID', 'Revenue_per_Budget']].head())