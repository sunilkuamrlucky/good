import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

df = pd.read_csv('Simple_Social_Media_Analysis_30_Rows.csv')  


df.columns = df.columns.str.strip().str.lower()  


df.dropna(subset=['Campaign_ID', 'Campaign_Name', 'Platform', 'Budget', 'Target_Audience', 'Objective'], inplace=True)


df['Campaign_ID'] = pd.to_numeric(df['Campaign_IDtity'], errors='coerce')
df['Budget'] = pd.to_numeric(df['Budget'], errors='coerce')
df['Target_Audienc'] = pd.to_numeric(df['Target_Audiencate'], errors='coerce')
df.dropna(inplace=True)

df['revenue'] = df['Budget'] * df['Target_Audience']


revenue_per_Budget = df.groupby('Budget')['revenue'].sum().sort_values(ascending=False)
print("Total Revenue per Budget:")
print(revenue_per_Budget)


top_5 = revenue_per_Budget.head(5)
print(df)

plt.figure(figsize=(10, 6))
sns.barplot(x=top_5.values, y=top_5.index, palette='coolwarm')
plt.title('Top 5 Selling Products by Revenue')
plt.xlabel('Total Revenue')
plt.ylabel('Product')
plt.tight_layout()
plt.show()