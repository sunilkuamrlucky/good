import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
import mysql.connector
print("MySQL connector installed and working!")



# Enable seaborn theme
sns.set(style="whitegrid")

# Connect to the MySQL database
conn = mysql.connector.connect(
    host='localhost',
    user='your_username',
    password='your_password',
    database='social_media_analysis'
)

# Load all tables
campaign_df = pd.read_sql("SELECT * FROM campaign_data", conn)
customer_df = pd.read_sql("SELECT * FROM customer_data", conn)
sales_df = pd.read_sql("SELECT * FROM sales_data", conn)
traffic_df = pd.read_sql("SELECT * FROM website_traffic", conn)

platform_counts = customer_df['Platform_Engaged'].value_counts()
plt.figure(figsize=(8,6))
plt.pie(platform_counts, labels=platform_counts.index, autopct='%1.1f%%', startangle=140)
plt.title('Customer Engagement by Platform')
plt.show()

revenue_df = pd.read_sql("""
SELECT 
    c.Campaign_ID,
    c.Platform,
    SUM(s.Revenue) AS Total_Revenue
FROM 
    campaign_data c
JOIN 
    sales_data s ON c.Campaign_ID = s.Campaign_ID
GROUP BY 
    c.Campaign_ID, c.Platform
ORDER BY 
    Total_Revenue DESC
""", conn)

plt.figure(figsize=(10,6))
sns.barplot(data=revenue_df, x='Campaign_ID', y='Total_Revenue', hue='Platform')
plt.title('Revenue by Campaign and Platform')
plt.xticks(rotation=45)
plt.show()

age_group_df = pd.read_sql("""
SELECT 
    CASE
        WHEN Age < 25 THEN '18-24'
        WHEN Age BETWEEN 25 AND 34 THEN '25-34'
        WHEN Age BETWEEN 35 AND 44 THEN '35-44'
        ELSE '45+'
    END AS Age_Group,
    COUNT(*) AS Customer_Count
FROM 
    customer_data
GROUP BY 
    Age_Group
""", conn)

plt.figure(figsize=(8,5))
sns.barplot(data=age_group_df, x='Age_Group', y='Customer_Count', palette='pastel')
plt.title('Customer Distribution by Age Group')
plt.show()

roi_df = pd.read_sql("""
SELECT 
    c.Campaign_ID,
    SUM(s.Revenue) / c.Ad_Spend AS ROI
FROM 
    campaign_data c
JOIN 
    sales_data s ON c.Campaign_ID = s.Campaign_ID
GROUP BY 
    c.Campaign_ID, c.Ad_Spend
""", conn)

plt.figure(figsize=(10,6))
sns.barplot(data=roi_df, x='Campaign_ID', y='ROI', palette='Blues_d')
plt.title('ROI by Campaign')
plt.show()

engagement_df = pd.read_sql("""
SELECT 
    Platform,
    SUM(Clicks) / SUM(Impressions) AS Engagement_Rate
FROM 
    campaign_data
GROUP BY 
    Platform
ORDER BY 
    Engagement_Rate DESC
""", conn)

plt.figure(figsize=(10,6))
sns.barplot(data=engagement_df, x='Platform', y='Engagement_Rate', palette='muted')
plt.title('Engagement Rate by Platform')
plt.show()

insta_traffic = traffic_df[traffic_df['Platform'] == 'Instagram']

plt.figure(figsize=(10,6))
sns.lineplot(data=insta_traffic, x='Date', y='Visits')
plt.title('Instagram Website Visits Over Time')
plt.xticks(rotation=45)
plt.tight_layout()
plt.show()
