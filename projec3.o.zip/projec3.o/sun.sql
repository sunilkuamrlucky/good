CREATE DATABASE social_media_analysis;
USE social_media_analysis;
SET GLOBAL local_infile = 1;
CREATE TABLE campaign_data (
    Campaign_ID VARCHAR(10),
    Platform VARCHAR(50),
    Start_Date DATE,
    End_Date DATE,
    Ad_Spend DECIMAL(10,2),
    Impressions INT,
    Clicks INT,
    Conversions INT
);

CREATE TABLE customer_data (
    Customer_ID VARCHAR(10),
    Age INT,
    Gender VARCHAR(10),
    Location VARCHAR(50),
    Platform_Engaged VARCHAR(50)
);

CREATE TABLE sales_data (
    Transaction_ID VARCHAR(10),
    Customer_ID VARCHAR(10),
    Purchase_Date DATE,
    Product_Category VARCHAR(50),
    Revenue DECIMAL(10,2),
    Campaign_ID VARCHAR(10)
);

CREATE TABLE website_traffic (
    Date DATE,
    Platform VARCHAR(50),
    Visits INT,
    Bounce_Rate DECIMAL(5,2),
    Session_Duration INT
);
 SELECT * FROM campaign_data;
 SELECT * FROM customer_data;
 SELECT * FROM sales_data;
 SELECT * FROM website_traffic;
 
 SELECT * FROM website_traffic WHERE Platform='Instagram';
 
 SELECT 
    c.Campaign_ID,
    c.Platform,
    SUM(s.Revenue) AS Total_Revenue
FROM 
    campaign_data c
JOIN 
    sales_data s ON c.Campaign_ID = s.Campaign_ID
GROUP BY 
    c.Campaign_ID, c.Platform
ORDER BY 
    Total_Revenue DESC;
    
    SELECT 
    CASE
        WHEN Age < 25 THEN '18-24'
        WHEN Age BETWEEN 25 AND 34 THEN '25-34'
        WHEN Age BETWEEN 35 AND 44 THEN '35-44'
        ELSE '45+'
    END AS Age_Group,
    COUNT(*) AS Customer_Count
FROM 
    customer_data
GROUP BY 
    Age_Group;
    
SELECT 
    c.Campaign_ID,
    SUM(s.Revenue) / c.Ad_Spend AS ROI
FROM 
    campaign_data c
JOIN 
    sales_data s ON c.Campaign_ID = s.Campaign_ID
GROUP BY 
    c.Campaign_ID, c.Ad_Spend;

SELECT 
    Platform,
    SUM(Clicks) / SUM(Impressions) AS Engagement_Rate
FROM 
    campaign_data
GROUP BY 
    Platform
ORDER BY 
    Engagement_Rate DESC;
 
 
 